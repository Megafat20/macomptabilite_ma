

<?php $__env->startSection('title', 'Nouvelle Facture'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Ajouter une facture</h3>
        </div>
        <form action="<?php echo e(route('factures.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <?php if($selectedEntrepriseId): ?>
                        
                        <input type="hidden" name="entreprise_id" value="<?php echo e($selectedEntrepriseId); ?>">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Entreprise</label>
                                <input type="text" class="form-control"
                                    value="<?php echo e($entreprises->find($selectedEntrepriseId)->nom ?? 'N/A'); ?>" disabled>
                                <small class="text-muted">L'entreprise est pré-sélectionnée selon votre filtre</small>
                            </div>
                        </div>
                    <?php else: ?>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="entreprise_id">Entreprise</label>
                                <select name="entreprise_id" id="entreprise_id" class="form-control" required>
                                    <option value="">Sélectionner une entreprise</option>
                                    <?php $__currentLoopData = $entreprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entreprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($entreprise->id); ?>"
                                            <?php echo e(old('entreprise_id') == $entreprise->id ? 'selected' : ''); ?>>
                                            <?php echo e($entreprise->nom); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="type">Type</label>
                            <select name="type" id="type" class="form-control" required>
                                <option value="actif" <?php echo e(old('type') == 'actif' ? 'selected' : ''); ?>>Actif (Facture Client)
                                </option>
                                <option value="passif" <?php echo e(old('type') == 'passif' ? 'selected' : ''); ?>>Passif (Facture
                                    Fournisseur)</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="tiers">Tiers (Client / Fournisseur)</label>
                            <input type="text" name="tiers" id="tiers" class="form-control"
                                value="<?php echo e(old('tiers')); ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="numero_facture">Numéro de Facture</label>
                            <input type="text" name="numero_facture" id="numero_facture" class="form-control"
                                value="<?php echo e(old('numero_facture')); ?>">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="date_facture">Date de Facture</label>
                            <input type="date" name="date_facture" id="date_facture" class="form-control"
                                value="<?php echo e(old('date_facture')); ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="montant">Montant (DH)</label>
                            <input type="number" step="0.01" name="montant" id="montant" class="form-control"
                                value="<?php echo e(old('montant')); ?>" required>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Description (Optionnel)</label>
                    <textarea name="description" id="description" class="form-control" rows="3"><?php echo e(old('description')); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="pieces_jointes">Pièces jointes (PDF, Image)</label>
                    <div class="input-group">
                        <div class="custom-file">
                            <input type="file" name="pieces_jointes[]" class="custom-file-input" id="pieces_jointes"
                                multiple>
                            <label class="custom-file-label" for="pieces_jointes">Choisir des fichiers</label>
                        </div>
                    </div>
                    <small class="form-text text-muted">Vous pouvez sélectionner plusieurs fichiers.</small>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Enregistrer</button>
                <a href="<?php echo e(route('factures.index')); ?>" class="btn btn-default">Annuler</a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Plugin for custom file input
        $(function() {
            // bsCustomFileInput.init(); // Requires bs-custom-file-input script if you want it
            $('.custom-file-input').on('change', function() {
                var fileName = $(this).val().split('\\').pop();
                $(this).next('.custom-file-label').addClass("selected").html(fileName);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\gestion_facturation\resources\views/factures/create.blade.php ENDPATH**/ ?>