

<?php $__env->startSection('title', 'Liste des Factures'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-3">
        <div class="col-md-4">
            <div class="info-box bg-success">
                <span class="info-box-icon"><i class="fas fa-arrow-up"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Total Actif (Recettes)</span>
                    <span class="info-box-number"><?php echo e(number_format($totalActif ?? 0, 2)); ?> DH</span>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="info-box bg-danger">
                <span class="info-box-icon"><i class="fas fa-arrow-down"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Total Passif (Dépenses)</span>
                    <span class="info-box-number"><?php echo e(number_format($totalPassif ?? 0, 2)); ?> DH</span>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="info-box <?php echo e(($solde ?? 0) >= 0 ? 'bg-info' : 'bg-secondary'); ?>">
                <span class="info-box-icon"><i class="fas fa-balance-scale"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Solde</span>
                    <span class="info-box-number"><?php echo e(number_format($solde ?? 0, 2)); ?> DH</span>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Factures</h3>
            <div class="card-tools">
                <a href="<?php echo e(route('factures.create', ['entreprise_id' => request('entreprise_id')])); ?>"
                    class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Nouvelle Facture
                </a>
            </div>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('factures.index')); ?>" method="GET" class="mb-3">
                <div class="row">
                    <div class="col-md-3">
                        <select name="entreprise_id" class="form-control mb-2">
                            <option value="">-- Toutes les entreprises --</option>
                            <?php $__currentLoopData = $entreprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entreprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($entreprise->id); ?>"
                                    <?php echo e(request('entreprise_id') == $entreprise->id ? 'selected' : ''); ?>>
                                    <?php echo e($entreprise->nom); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="type" class="form-control mb-2">
                            <option value="">-- Type --</option>
                            <option value="actif" <?php echo e(request('type') == 'actif' ? 'selected' : ''); ?>>Actif</option>
                            <option value="passif" <?php echo e(request('type') == 'passif' ? 'selected' : ''); ?>>Passif</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="statut" class="form-control mb-2">
                            <option value="">-- Statut --</option>
                            <option value="paye" <?php echo e(request('statut') == 'paye' ? 'selected' : ''); ?>>Payé</option>
                            <option value="impaye" <?php echo e(request('statut') == 'impaye' ? 'selected' : ''); ?>>Impayé</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="search" class="form-control mb-2" placeholder="N° Facture ou Tiers"
                            value="<?php echo e(request('search')); ?>">
                    </div>
                    <div class="col-md-2">
                        <div class="d-flex">
                            <input type="date" name="date_debut" class="form-control mb-2 mr-1"
                                value="<?php echo e(request('date_debut')); ?>" title="Date début">
                            <input type="date" name="date_fin" class="form-control mb-2"
                                value="<?php echo e(request('date_fin')); ?>" title="Date fin">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-default btn-block"><i class="fas fa-filter"></i>
                            Filtrer</button>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" name="export" value="1" class="btn btn-success btn-block"><i
                                class="fas fa-file-excel"></i> Exporter</button>
                    </div>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Entreprise</th>
                            <th>Tiers</th>
                            <th>Type</th>
                            <th>Statut</th>
                            <th>Montant</th>
                            <th>N° Facture</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $factures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(\Carbon\Carbon::parse($facture->date_facture)->format('d/m/Y')); ?></td>
                                <td><?php echo e($facture->entreprise->nom ?? 'N/A'); ?></td>
                                <td><?php echo e($facture->tiers); ?></td>
                                <td>
                                    <?php if($facture->type == 'actif'): ?>
                                        <span class="badge badge-success">Actif</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Passif</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($facture->statut == 'paye'): ?>
                                        <button type="button" class="btn badge badge-success btn-status-action"
                                            data-toggle="modal" data-target="#statusModal" data-id="<?php echo e($facture->id); ?>"
                                            data-statut="paye" style="border:none; cursor:pointer;">
                                            Payé
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn badge badge-warning btn-status-action btn-sparkle"
                                            data-toggle="modal" data-target="#statusModal" data-id="<?php echo e($facture->id); ?>"
                                            data-statut="impaye" style="border:none; cursor:pointer;">
                                            Impayé
                                        </button>
                                    <?php endif; ?>
                                </td>
                                <td class="text-right"><?php echo e(number_format($facture->montant, 2)); ?> DH</td>
                                <td><?php echo e($facture->numero_facture); ?></td>
                                <td>
                                    <a href="<?php echo e(route('factures.show', $facture->id)); ?>" class="btn btn-info btn-xs"><i
                                            class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('factures.edit', $facture->id)); ?>"
                                        class="btn btn-warning btn-xs"><i class="fas fa-edit"></i></a>
                                    <form action="<?php echo e(route('factures.destroy', $facture->id)); ?>" method="POST"
                                        style="display:inline;" onsubmit="return confirm('Êtes-vous sûr ?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-xs"><i
                                                class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">Aucune facture trouvée.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-3">
                <?php echo e($factures->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>

    <!-- Modal Status -->
    <div class="modal fade" id="statusModal" tabindex="-1" role="dialog" aria-labelledby="statusModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="statusForm" method="POST" action="">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="statusModalLabel">Modifier le statut</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="modalStatut">Statut de la facture</label>
                            <select name="statut" id="modalStatut" class="form-control">
                                <option value="paye">Payé</option>
                                <option value="impaye">Impayé</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#statusModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget)
            var id = button.data('id')
            var statut = button.data('statut')

            var modal = $(this)
            // Update form action dynamically
            var url = "<?php echo e(route('factures.update-status', ':id')); ?>";
            url = url.replace(':id', id);
            modal.find('#statusForm').attr('action', url);

            // Set current status
            modal.find('#modalStatut').val(statut);
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\gestion_facturation\resources\views/factures/index.blade.php ENDPATH**/ ?>